<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'Signup_controller';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Signup_controller';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['menucreation'] = 'Admin/MenuSelection/MenuCreation';
$route['menuinst/index'] = 'Admin/MenuSelection/MenuInstController';
$route['menuinst'] = 'Admin/MenuSelection/MenuInstController';
$route['menuinst/savemenudata'] = 'Admin/MenuSelection/MenuInstController/saveMenuData';
$route['iteminst/index'] = 'Admin/MenuSelection/ItemInstController';
$route['iteminst'] = 'Admin/MenuSelection/ItemInstController';
$route['iteminst/saveitemdata'] = 'Admin/MenuSelection/ItemInstController/saveItemData';
$route['menuitemsel'] = 'Admin/MenuSelection/MenuItemSelController';
$route['menuitemsel/ajaxitem'] = 'Admin/MenuSelection/MenuItemSelController/ajaxItem';
$route['Access_controller/iteminst']="Admin/MenuSelection/ItemInstController";
$route[] = 'Signup_controller/RegisterUser';
$route['Access_controller/menuinst'] = 'Admin/MenuSelection/MenuInstController'; 
$route['Access_controller/menuitemsel'] = 'Admin/MenuSelection/MenuItemSelController';
$route[] = 'Access_controller/manageProfile';
$route['menuitemsel/insertmenuitem'] = 'Admin/MenuSelection/MenuItemSelController/insertMenuItem';
$route['menuinst/edit/:num'] = 'Admin/MenuSelection/MenuInstController/editMenu';
$route['menuinst/delete/:num'] = 'Admin/MenuSelection/MenuInstController/deleteMenu';
$route['iteminst/edit/:num'] = 'Admin/MenuSelection/ItemInstController/editItem';
$route['iteminst/delete/:num'] = 'Admin/MenuSelection/ItemInstController/deleteItem';
$route['Signup_controller/dashboard'] = 'Admin/Dashboard/DashboardController';
$route['dashboard']= 'Admin/Dashboard/DashboardController';
$route['dashboard/index/:num/:num'] = 'Admin/Dashboard/DashboardController';
$route['menusel/display'] = 'Parent/ChildMenuItemController/displayMenuItem';
$route['menusel'] = 'Parent/ChildMenuItemController';
$route['menusel/showMenu'] = 'Parent/ChildMenuItemController/showMenu';
//$route['menusel/index'] = 'Parent/ChildMenuItemController/index';
$route['menusel/showItem/:num'] = 'Parent/ChildMenuItemController/showItem';
$route['Access_controller/dashboard'] = 'Admin/Dashboard/DashboardController';
$route['logout'] = 'Signup_controller/logout';
$route['SARedirection']='Access_controller/manageProfile';
$route['ParentRedirection']='Access_controller/manageProfile';
$route['Signup_controller/menuinst']= 'Admin/MenuSelection/MenuInstController';
$route['Signup_controller/iteminst']= 'Admin/MenuSelection/ItemInstController';
$route['Signup_controller/menuitemsel']= 'Admin/MenuSelection/MenuItemSelController';
$route['Signup_controller/menuinst/edit/:num']= 'Admin/MenuSelection/MenuInstController/editMenu';
$route['menusel/children'] = 'Parent/ChildMenuItemController/showAllChildren';
$route['menusel/addchildmenu/:num'] = 'Parent/ChildMenuItemController/addChildMenu';
$route['menusel/childrenmenu'] = 'Parent/ChildMenuItemController/showAllChildrenMenu';
$route['menuitemsel/index'] = 'Admin/MenuSelection/MenuItemSelController';
$route['parentsel/index']= 'Admin/ParentMenuSelController';
$route['parentsel/parentslist']= 'Admin/ParentMenuSelController/parentsList';
$route['parentsel/parentchildrenlist']= 'Admin/ParentMenuSelController/parentChildrenList';
$route['parentsel/updatechilditem']= 'Admin/ParentMenuSelController/updateChildItem';
$route['menuitemsel/index/:num/:num'] = 'Admin/MenuSelection/MenuItemSelController';
$route['menuitemsel/menuselitemview/(:any)'] = 'Admin/MenuSelection/MenuItemSelController/menuSelItemView';
$route['menuitemsel/insertmenuitemdata'] = 'Admin/MenuSelection/MenuItemSelController/insertMenuItemData';
$route['childMenuItem/children/(:any)'] = 'Parent/ChildMenuItemController/parentmenuselitemview';
$route['menuitemsel/ajaxitemsdisabling'] = 'Admin/MenuSelection/MenuItemSelController/ajaxItemsDisabling';
$route['ChildMenuItem/insertchildmenuitemdata'] = 'Parent/ChildMenuItemController/insertchildmenuitemdata';
$route['menusel/index'] = 'Parent/ChildMenuItemController';
$route['menuitemsel/displaydynamicmenuitem'] = 'Admin/MenuSelection/MenuItemSelController/displayDynamicMenuItem';
$route['childMenuItem/showselectItem'] = 'Parent/ChildMenuItemController/showselectItem';
$route['mealcreation'] = 'Admin/MenuSelection/MealCreationController';
$route['mealcreation/savemenudata'] = 'Admin/MenuSelection/MealCreationController/saveMenuData';
$route['mealcreation/showallmeal'] = 'Admin/MenuSelection/MealCreationController/showAllMeal';
$route['mealcreation/showAllItems'] = 'Admin/MenuSelection/MealCreationController/showAllItems';
$route['mealcreation/mealitemInst'] = 'Admin/MenuSelection/MealCreationController/mealItemInst';
$route['mealcreation/itemInst'] = 'Admin/MenuSelection/MealCreationController/itemInst';
$route['mealcreation/delete'] = 'Admin/MenuSelection/MealCreationController/deleteMeal';
$route['adminmenuitemsel'] = 'Admin/MenuSelection/AdminMenuItemSelController';
$route['adminmenuitemsel/insertmenuitemdata'] = 'Admin/MenuSelection/AdminMenuItemSelController/insertMenuItemData';
$route['adminmenuitemsel/displaydynamicmenuitem'] = 'Admin/MenuSelection/AdminMenuItemSelController/displayDynamicMenuItem';
$route['bmiteminst'] = 'Admin/MenuSelection/BmItemInstController';
$route['bmiteminst/delete/:num'] = 'Admin/MenuSelection/BmItemInstController/deleteItem';
$route['bmiteminst/saveitemdata'] = 'Admin/MenuSelection/BmItemInstController/saveItemData';
$route['ChildMenuItemController/categoryItemMeal']='Parent/ChildMenuItemController/categoryItemMeal';
$route['ChildMenuItemController/insertMenuMealitem'] ='Parent/ChildMenuItemController/insertMenuMealitem';
$route['ParentApiController/allApiData']='Parent/ParentApiController/allApiData';
$route['childReport'] = 'Parent/ChildReportListController/index';
$route['ChildReportListController/childReportFilter'] = 'Parent/ChildReportListController/childReportFilter';
$route['bmiteminst/ajaxcheckitem'] = 'Admin/MenuSelection/BmItemInstController/ajaxCheckItem';
$route['bmiteminst/edit/:num'] = 'Admin/MenuSelection/BmItemInstController/editItem';
$route['mealcreation/ajaxcheckitem'] = 'Admin/MenuSelection/MealCreationController/ajaxCheckItem';
$route['ParentApiController/allApiData/(:any)']='Parent/ParentApiController/allApiData';
$route['iteminst/ajaxcheckitem'] = 'Admin/MenuSelection/ItemInstController/ajaxCheckItem';
$route['paymentackw/(:any)/(:any)/(:any)/(:any)/(:any)'] = 'Parent/ChildReportListController/paymentAckw';
$route['ChildMenuItemController/reportCheckout/(:any)/(:any)/(:any)'] ='Parent/ChildMenuItemController/reportCheckout';
$route['transReport'] = 'Parent/ChildReportListController/transactionReport';
$route['ChildReportListController/transactionReportFilter'] = 'Parent/ChildReportListController/transactionReportFilter';
$route['ChildReportListController/ajaxTransactionReport'] = 'Parent/ChildReportListController/ajaxTransactionReport';


















